<?= $this->extend('layouts/main') ?>

<div class="container">
    <h2>Parece que você não tem permissão para acessar o sistema</h2>
</div>
<?= $this->endSection() ?>